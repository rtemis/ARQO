#!/bin/bash

# Loop variables
Ninicio=896
Npaso=16
Nfinal=1024

# Files to be created
fDAT=traspuesta.dat
fPNG1=tras_cache.png

# Erase the files if they already exist
rm -f $fDAT fPNG1 

# Create blank .dat file
touch $fDAT

echo "Running normal y tras..."
for ((N = Ninicio, j = 1 ; N <=Nfinal ; N += Npaso, j++)); do
	D1mrT[$j]="0"
	D1mwT[$j]="0"
done
for ((N = Ninicio, j = 1 ; N <= Nfinal ; N += Npaso, j++)); do
	d=$(valgrind --tool=cachegrind --I1=8192,1,64 --D1=8192,1,64 --LL=8388608,1,64 --cachegrind-out-file=temp.dat ./traspuesta $N)
	missesR=$(cg_annotate temp.dat | head -n 30 | grep 'PROGRAM' | awk '{print $5}')
	missesW=$(cg_annotate temp.dat | head -n 30 | grep 'PROGRAM' | awk '{print $8}')
	x=${D1mrT[$j]}
	y=${D1mwT[$j]}
	# Update slow value for average calculation
	D1mrT[$j]=$(python -c "print( int('$missesR'.replace(',', '')) + $x )")
	D1mwT[$j]=$(python -c "print( int('$missesW'.replace(',', '')) + $y )")
done

# Loop for writing to file
for ((N = Ninicio, j = 1 ; N <= Nfinal ; N += Npaso, j++)); do
	trasR=$(python -c "print(${D1mrT[$j]})")
	trasW=$(python -c "print(${D1mwT[$j]})")
	echo "$N    $trasR    $trasW" >> $fDAT
done

