#!/bin/bash

# Loop variables
Ninicio=896
Npaso=16
Nfinal=1024

# Files to be created
fDAT=norm.dat
fPNG1=norm_cache.png

# Erase the files if they already exist
rm -f $fDAT fPNG1 

# Create blank .dat file
touch $fDAT

echo "Running normal y tras..."
for ((N = Ninicio, j = 1 ; N <=Nfinal ; N += Npaso, j++)); do
	D1mrN[$j]="0"
	D1mwN[$j]="0"
done
for ((N = Ninicio, j = 1 ; N <= Nfinal ; N += Npaso, j++)); do
	d=$(valgrind --tool=cachegrind --I1=8192,1,64 --D1=8192,1,64 --LL=8388608,1,64 --cachegrind-out-file=temp.dat ./normal $N)
	missesR=$(cg_annotate temp.dat | head -n 30 | grep 'PROGRAM' | awk '{print $5}')
	missesW=$(cg_annotate temp.dat | head -n 30 | grep 'PROGRAM' | awk '{print $8}')
	x=${D1mrN[$j]}
	y=${D1mwN[$j]}
	# Update slow value for average calculation
	D1mrN[$j]=$(python -c "print( int('$missesR'.replace(',', '')) + $x )")
	D1mwN[$j]=$(python -c "print( int('$missesW'.replace(',', '')) + $y )")
done

# Loop for writing to file
for ((N = Ninicio, j = 1 ; N <= Nfinal ; N += Npaso, j++)); do
	normalR=$(python -c "print(${D1mrN[$j]})")
	normalW=$(python -c "print(${D1mwN[$j]})")
	echo "$N    $normalR    $normalW" >> $fDAT
done

