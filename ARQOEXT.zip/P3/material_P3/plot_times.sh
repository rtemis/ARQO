rm -f times_mat.png

echo "Generating plot..."
# llamar a gnuplot para generar el gráfico y pasarle directamente por la entrada
# estándar el script que está entre "<< END_GNUPLOT" y "END_GNUPLOT"
gnuplot << END_GNUPLOT
set title "Matrix Time Comparison"
set ylabel "Time (s)"
set xlabel "Matrix Size"
set key right bottom
set grid
set term png
set yrange [*:]
set output "times_mat.png"
plot "norm-tras-time.dat" using 1:2 with lines lw 2 title "normal", \
     "norm-tras-time.dat" using 1:3 with lines lw 2 title "traspuesta"
replot
quit
END_GNUPLOT
