#!/bin/bash

# Loop variables
Ninicio=896
Npaso=32
Nfinal=1024

# Files to be created
fDAT=trascache.dat

# Erase the files if they already exist
rm -f $fDAT 

# Create blank .dat file
touch $fDAT

echo "Running normal"
# Loop for initializing data
for ((N = Ninicio, j = 1 ; N <=Nfinal ; N += Npaso, j++)); do
	D1mrN[$j]="0"
	D1mwN[$j]="0"
done

# Loop for valgrind data collection
for ((N = Ninicio, j = 1 ; N <= Nfinal ; N += Npaso, j++)); do
	d=$(valgrind --tool=cachegrind --I1=8192,1,64 --D1=8192,1,64 --LL=8388608,1,64 --cachegrind-out-file=tmp1.dat ./traspuesta $N)
	missesR=$(cg_annotate tmp1.dat | head -n 30 | grep 'PROGRAM' | awk '{print $5}')
	missesW=$(cg_annotate tmp1.dat | head -n 30 | grep 'PROGRAM' | awk '{print $8}')
	x=${D1mrN[$j]}
	y=${D1mwN[$j]}
	# Update slow value for average calculation
	D1mrN[$j]=$(python -c "print( int('$missesR'.replace(',', '')) + $x )")
	D1mwN[$j]=$(python -c "print( int('$missesW'.replace(',', '')) + $y )")
	echo "$N    ${D1mrN[$j]}    ${D1mwN[$j]}" >> fDAT
done
